<?php

namespace XDdAnIk\QueryGuard;

use pocketmine\event\Listener;
use pocketmine\block\Block;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\TextFormat as F;
use pocketmine\Server;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\CommandExecutor;
use pocketmine\math\Vector3;
use pocketmine\event\server\QueryRegenerateEvent;
use pocketmine\Player;
use pocketmine\scheduler\CallbackTask;

class QueryGuard extends PluginBase implements Listener {
	
	private $motd = "ForsLand";
	private $plugins = array();
	private $players = array();
	private $maxplayers = 1337228;
	private $world = "Личные данные";
	
	private $querystart = 0;
	
	public function onEnable() {
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
	} 
	
	public function onQuery(QueryRegenerateEvent $event){
		$event->setServerName($this->motd); //Motd
		
		#==============OnePluginOneServer==============
		$allPlugins = $event->getPlugins();
		if(!$this->plugins){
			foreach($allPlugins as $p){
				$d = $p->getDescription();
				if($d->getName() == "Личные данные"){
					$this->plugins[] = $p;
				}
			}
		}
		$event->setPlugins($this->plugins); //Plugins
		 
		if($this->querystart == 0){
			$this->getServer()->getLogger()->info("[QueryGuard] Защита заработала.");
			$this->querystart = 1;
		}
		$event->setPlayerList($this->players); //Players
		$event->setMaxPlayerCount($this->maxplayers); //MaxPlayers
		$event->setWorld($this->world); //World
	}
}