# PurePerms

[![Join the chat at https://gitter.im/PurePlugins/PurePerms](https://badges.gitter.im/PurePlugins/PurePerms.svg)](https://gitter.im/PurePlugins/PurePerms?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

![PurePerms](https://raw.githubusercontent.com/PurePlugins/PurePerms/master/PurePerms.png)

"Manage your permissions like you did on Bukkit"
