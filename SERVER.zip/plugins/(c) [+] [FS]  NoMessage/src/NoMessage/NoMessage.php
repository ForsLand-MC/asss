<?php

namespace NoMessage;

use pocketmine\plugin\PluginBase;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\Listener;

class NoMessage extends PluginBase implements Listener {
    
    public function onEnable() {
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
    }
	
	public function onPlayerJoinEvent(PlayerJoinEvent $event) {
		$event->setJoinMessage("");
	}
	
	public function onPlayererQuitEvent(PlayerQuitEvent $event) {
		$event->setQuitMessage("");
	}
}