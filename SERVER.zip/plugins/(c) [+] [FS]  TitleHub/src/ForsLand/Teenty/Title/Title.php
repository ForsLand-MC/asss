<?php

namespace ForsLand\Teenty\Title;

use pocketmine\plugin\PluginBase;

use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\Listener;

use pocketmine\Player;
use pocketmine\Server;

use pocketmine\scheduler\CallbackTask;

class Title extends PluginBase implements Listener {

     public function onEnable() {
         $this->getServer()->getPluginManager()->registerEvents($this, $this);
   }
     public function onPlayerJoinEvent(PlayerJoinEvent $e) {
         $player = $e->getPlayer();
		 $player->addTitle("§l§4Fors§6Land");
   }
 }
?>
