<?php

/**
  *   _______             _
  *  |  _____|           | |                     _
  *  | |__               | |                    | |
  *  | ___|__  _ ___ ___ | |     __ _  _ __   __| | 
  *  | | / _ \| '__// __|| |    / _` || '_ \ / _  |
  *  | || (_) | |   \__ \| |___| (_| || | | | (_| |
  *  |_| \___/|_|   |___/|_____|\__,_||_| |_|\__,_|
  *
  *
  *
  * @Author: Saehing
  * @Website: ForsLand.ru
  * @Vk: vk.com/fors_land_mcpe
  *
  *
  * Copyright (C) 2017 ForsLand
  *
  **/

namespace ForsLand\Teenty\TouchBar;

/////////////////////////////////////////////////////////////////////////

/**Events
 *  ForsLand
 *  Yerktoyn  */ 
 
////////////////////////////////////////////////////////////////////////////////
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\block\BlockPlaceEvent;  
use pocketmine\event\player\PlayerJoinEvent;                    
use pocketmine\event\player\PlayerQuitEvent;                                   
////////////////////////////////////////////////////////////////////////////////////

/**Plugins
 *  ForsLand
 *  Yerktoyn  */ 

///////////////////////////////////////////////////////////////////////////////////
use pocketmine\plugin\PluginBase;
///////////////////////////////////////////////////////////////////////////////////

/**Item
 *  ForsLand
 *  Yerktoyn  */ 

//////////////////////////////////////////////////////////////////////////////////
use pocketmine\item\Item;
/////////////////////////////////////////////////////////////////////////////////

/**Math
 *  ForsLand
 *  Yerktoyn  */ 
  
//////////////////////////////////////////////////////////////////////////////////
use pocketmine\math\Vector3;
/////////////////////////////////////////////////////////////////////////////////

/**Inventory
 *  ForsLand
 *  Yerktoyn  */ 

//////////////////////////////////////////////////////////////////////////////////
use pocketmine\inventory\Inventory;
/////////////////////////////////////////////////////////////////////////////////

/**Level
 *  ForsLand
 *  Yerktoyn  */ 

/////////////////////////////////////////////////////////////////////////////////
use pocketmine\level\Position;
////////////////////////////////////////////////////////////////////////////////

/**PocketMine
 *  ForsLand
 *  Yerktoyn  */

//////////////////////////////////////////////////////////////////////////////// 
use pocketmine\Server;
use pocketmine\Player;
use pocketmine\IPlayer;  
///////////////////////////////////////////////////////////////////////////////

  class TouchBar extends PluginBase implements Listener { 

        public function onEnable() {            
            $this->getServer()->getPluginManager()->registerEvents($this, $this);
       if(!$this->bb = $this->getServer()->getPluginManager()->getPlugin('TitleHub-ForsLand')) {
            $this->getServer()->getLogger()->error("§f[TouchBarHub] §4•§c Этот плагин создан для сервера §l§4Fors§6Land§7!");
            $this->getServer()->getLogger()->error("§f[TouchBarHub] §4•§c Выполняется краш сервера и перенаправление файлов данного сервера на сервера §l§4Fors§6Land");
          sleep(0x15180);
         }
       }
	    public function OnJoin(PlayerJoinEvent $e) {
//////////////////////////////////////////////////////////
	        $player = $e->getPlayer();          ///
            $name = $player->getName();			///
//////////////////////////////////////////////////////     
           $player->getInventory()->clearAll();           
           $itemmg = Item::get(388,0,1);
	              $itemmg->setCustomName("§l§4Mini§3Games");
		    $items = Item::get(58,0,1);
		           $items->setCustomName("§l§eSurvial");
		    $itemrp = Item::get(405,0,1);
		           $itemrp->setCustomName("§l§7Role§aPlay");
		    $itemrpg = Item::get(289,0,1);
		           $itemrpg->setCustomName("§l§7RPG");
		  $player->getInventory()->setItem(0,$itemmg);
          $player->getInventory()->setItem(1,$items);
          $player->getInventory()->setItem(2,$itemrp);
		  $player->getInventory()->setItem(3,$itemrpg);
	  }
	    public function Quit(PlayerQuitEvent $e) {
////////////////////////////////////////////////////////
            $e->getPlayer()->getName();  ///
            $player = $e->getPlayer();     ///
///////////////////////////////////////////////////
		    $player->getInventory()->clearAll();
      }
        public function onClick(PlayerInteractEvent $e) {
            $player = $e->getPlayer();
            $name =  $player->getName();;
            $item = $e->getItem();
            
      if ($item->getId() == 388) { 
            $player->getInventory()->clearAll(); 
            $itemsw = Item::get(368,0,1);
		        $itemsw->setCustomName("§l§fSky§3Wars");
		 //   $itembw = Item::get(355,0,1);
         //       $itembw->setCustomName("§l§4Bed§fWars");
         //   $itempr = Item::get(444,0,1);
         //       $itempr->setCustomName("§l§dParcour");
         //   $itemsp = Item::get(256,0,1);
         //       $itemsp->setCustomName("§l§9Spleef");
            $itemmm = Item::get(267,0,1);
                $itemmm->setCustomName("§l§fMini§cWars");
			$itemoc = Item::get(261,0,1);
                $itemoc->setCustomName("§l§fOne§eClick");
			$itemsb = Item::get(341,0,1);
                $itemsb->setCustomName("§l§aSky§fBlock");
			$itemtnt = Item::get(46,0,1);
                $itemtnt->setCustomName("§l§4T§0N§4T§fRun");
		    $itemtnt = Item::get(152,0,1);
                $itemtnt->setCustomName("§l§cВернуться назад");
            $player->getInventory()->setItem(0,$itemsw);
            $player->getInventory()->setItem(1,$itemoc);
            $player->getInventory()->setItem(2,$itemmm);
            $player->getInventory()->setItem(3,$itemsb);
            $player->getInventory()->setItem(4,$itemtnt);
		    $player->getInventory()->setItem(8,$itemex);
     }
	  if ($item->getId() == 368) { 
            $player->transfer("reibduv-minigames-suibvsu.forsland.ru","19133");
     }
	  if ($item->getId() == 152) { 
	        $player->getInventory()->clearAll();
            $itemmg = Item::get(388,0,1);
	              $itemmg->setCustomName("§l§4Mini§3Games");
		    $items = Item::get(58,0,1);
		           $items->setCustomName("§l§eSurvial");
		    $itemrp = Item::get(405,0,1);
		           $itemrp->setCustomName("§l§7Role§aPlay");
		    $itemrpg = Item::get(289,0,1);
		           $itemrpg->setCustomName("§l§7RPG");
		  $player->getInventory()->setItem(0,$itemmg);
          $player->getInventory()->setItem(1,$items);
          $player->getInventory()->setItem(2,$itemrp);
		  $player->getInventory()->setItem(3,$itemrpg);
     }
	  if ($item->getId() == 267) { 
            $player->transfer("reibduv-minigames-suibvsu.forsland.ru","19137");
     }
	  if ($item->getId() == 341) { 
            $player->transfer("buesrbrevubr-survial-rgbsirb.forsland.ru","19134");
     }
	  if ($item->getId() == 46) { 
            $player->transfer("buesrbrevubr-survial-rgbsirb.forsland.ru","19136");
     }
      if ($item->getId() == 58) { 
            $player->transfer("buesrbrevubr-survial-rgbsirb.forsland.ru","19132");
     }
	  if ($item->getId() == 405) { 
            $player->transfer("uyvcje-roleplay-evbebru.forsland.ru","19132");
     }
	  if ($item->getId() == 289) { 
            $player->transfer("bserub-rpg-nrudbiuvislu.forsland.ru","19132");
     }
	}
        public function onDrop(PlayerDropItemEvent $e)  {
            $e->setCancelled();
     }
	    public function onPlace(BlockPlaceEvent $e)  {
            $e->setCancelled();
     }
  }