PureChat
========

[![Join the chat at https://gitter.im/PurePlugins/PureChat](https://badges.gitter.im/PurePlugins/PureChat.svg)](https://gitter.im/PurePlugins/PureChat?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

...
