<?php

namespace SanBotPE;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerPreLoginEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase implements Listener{

    private $IPs = [];

    public function onEnable(){
        $this->saveDefaultConfig();
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onPreLog(PlayerPreLoginEvent $event){
        isset($this->IPs[$ip = $event->getPlayer()->getAddress()]) ? $this->IPs[$ip] += 1 : $this->IPs[$ip] = 1;
        if($this->IPs[$ip] > $this->getConfig()->get("max-cons", 5)){
            $event->setKickMessage("Забанен защитой от DDoS");
            switch($this->getConfig()->get("action", "ban-ip")){
                case "ban-ip":
                    $event->setCancelled();
                    $this->getServer()->getIPBans()->addBan($ip, "Забанен защитой от DDoS");
                    foreach($this->getServer()->getOnlinePlayers() as $p){
                        if($p !== $event->getPlayer() and $p->getAddress() === $ip){
                            $p->kick("Забанен защитой от DDoS", false);
                        }
                    }
                break;
                case "ban-name-new-entries":
                    $event->setCancelled();
                    $this->getServer()->getNameBans()->addBan($event->getPlayer()->getName(), "Забанен защитой от DDoS");
                break;
                case "ban-name-all":
                    $event->setCancelled();
                    foreach($this->getServer()->getOnlinePlayers() as $p){
                        if($p !== $event->getPlayer() and $p->getAddress() === $ip){
                            $p->setBanned(true);
                        }
                    }
                break;
                case "kick-new-entries":
                    $event->setCancelled();
                break;
                case "kick-all":
                    $event->setCancelled();
                    foreach($this->getServer()->getOnlinePlayers() as $p){
                        if($p !== $event->getPlayer() and $p->getAddress() === $ip){
                            $p->kick();
                        }
                    }
                break;
            }
        }
    }

    public function onQuit(PlayerQuitEvent $event){
        if(isset($this->IPs[$event->getPlayer()->getAddress()])){
            $this->IPs[$event->getPlayer()->getAddress()] -= 1;
        }
    }

}