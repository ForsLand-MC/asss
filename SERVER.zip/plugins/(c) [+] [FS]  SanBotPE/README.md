# SanBotPE(Защита от Ддоса)
SanBot запрещает заходить много раз(иначе бан ИП) с 1 ИП,можно настроить в конфиге!
Мой сайт sanndroid-serv.ru
Моя группа vk.com/sanndroid
Я сам vk.com/santiaga007007
