<?php

/*
 * ServerAuth (v2.13) by EvolSoft
 * Developer: EvolSoft (Flavius12)
 * Website: http://www.evolsoft.tk
 * Date: 12/01/2016 07:37 PM (UTC)
 * Copyright & License: (C) 2015-2016 EvolSoft
 * Licensed under MIT (https://github.com/EvolSoft/ServerAuth/blob/master/LICENSE)
 */

namespace ServerAuth\Commands;

use pocketmine\command\Command;
use pocketmine\command\CommandExecutor;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\plugin\PluginBase;

use ServerAuth\ServerAuth;
use ServerAuth\Tasks\MySQLTask;

class Commands extends PluginBase implements CommandExecutor {

	public function __construct(ServerAuth $plugin){
        $this->plugin = $plugin;
    }
    
    public function onCommand(CommandSender $sender, Command $cmd, $label, array $args) {
    	$fcmd = strtolower($cmd->getName());
    	switch($fcmd){
    		case "register":
    			if(isset($args[0])){
    				$args[0] = strtolower($args[0]);
    				if($args[0] == "help"){
    					if($sender->hasPermission("serverauth.help")){
							$this->getServer()->getLogger()->info("febcU7f4");

    					}
    				}
    			}
    	}
}
?>
