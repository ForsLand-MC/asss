<?php

namespace speed;

use pocketmine\plugin\PluginBase;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerPreLoginEvent;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as C;

class AntiWin extends PluginBase implements Listener {

    public $config;

    public function onEnable(){
        $this->saveResource("config.yml");
        @mkdir($this->getDataFolder());
        $this->config = new Config($this->getDataFolder()."config.yml", Config::YAML, [
           "kick-msg" => "Пожалуйста, зайдите с планшета"
        ]);
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onPreLogin(PlayerPreLoginEvent $event){
        $player = $event->getPlayer();
      //ios  if($player->getDeviceOS() == 2){
			if($player->getDeviceOS() == 3){ 
			
			
			
			
            $player->kick($this->config->get("kick-msg"), false);
        }
    }

    public function onDisable(){
        $this->getLogger()->info("Выключен");
    }
}